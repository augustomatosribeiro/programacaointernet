let quantidadePessoas = document.querySelector("#quantidadePessoas");
let BTcalcular = document.querySelector("#BTcalcular");
let resultadoOvos = document.querySelector("#resultadoOvos");
let resultadoQueijo = document.querySelector("#resultadoQueijo");

function calcularIngredientes() {

    let num1 = Number(quantidadePessoas.value);
    
    resultadoOvos.textContent = (num1*2) + " ovos";
    resultadoQueijo.textContent = (num1*50) + " gramas";

   
}

BTcalcular.onclick = function () {
    calcularIngredientes();
};