let saldo1 = document.querySelector("#saldo1");
let saldo2 = document.querySelector("#saldo2");
let btsomar = document.querySelector("#btsomar");
let resultado = document.querySelector("#resultado");

function imprimirsaldo(){

let num1 = Number (saldo1.value) 


resultado.textContent =  (num1*(1/100)) + num1;
 
}

btsomar.onclick = function (){

    imprimirsaldo();
}