let valorDollar= document.querySelector("#valorDollar");
let BTcalcular= document.querySelector("#BTcalcular");
let resultado1= document.querySelector("#resultado1");
let resultado2= document.querySelector("#resultado2");
let resultado5= document.querySelector("#resultado5");
let resultado10= document.querySelector("#resultado10");

function porcentagemDollar(){ 

  let num1 = Number(valorDollar.value);

  resultado1.textContent = (num1*(1/100)) + num1;
  resultado2.textContent = (num1*(2/100)) + num1;
  resultado5.textContent = (num1*(5/100)) + num1;
  resultado10.textContent = (num1*(10/100)) + num1;
}

BTcalcular.onclick = function(){
    porcentagemDollar()
}