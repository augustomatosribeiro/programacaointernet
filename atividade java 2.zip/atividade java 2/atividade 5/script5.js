let valor1 = document.querySelector("#valor1")
let valor2 = document.querySelector("#valor2")
let btsomar = document.querySelector("#btsomar")
let resultado = document.querySelector("#resultado")

function maiorentreeles(){

if(valor1 > valor2) {


resultado.textContent = "valor1 e maior !"

else if(valor2 > valor1){
    (resultado.textContent) = "valor2 e maior"
}
else{
    resultado.textContent = "os dois valores sao iguais"
}

btsomar.onclick = function (){
    maiorentreeles()
}

