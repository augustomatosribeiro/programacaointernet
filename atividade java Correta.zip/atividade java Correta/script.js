let valorpago = document.querySelector ("#valorpago");
let precoproduto = document.querySelector("#precoproduto");
let btsomar = document.querySelector("#btsomar");
let H3resultadoo = document.querySelector("#H3resultadoo");

function trocoproduto(){

let num1 = Number (valorpago.value)
let num2 = Number (precoproduto.value)

H3resultadoo.textContent = (num1 - num2);

}

btsomar.onclick = function(){

    trocoproduto();

}