let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let BTcalcular = document.querySelector("#BTcalcular");
let resultadosoma = document.querySelector("#resultadosoma");
let resultadosubtracao = document.querySelector("#resultadosubtracao");
let resultadomultiplicacao = document.querySelector("#resultadomultiplicacao");
let resultadodivisao = document.querySelector("#resultadodivisao");

function exibirnumeros(){

let num1 = Number (numero1.value);
let num2 = Number (numero2.value);

resultadosoma.textContent = (num1+num2);
resultadosubtracao.textContent = (num1-num2);
resultadomultiplicacao.textContent = (num1*num2);
resultadodivisao.textContent = (num1/num2);


}

BTcalcular.onclick = function (){

    exibirnumeros();

}