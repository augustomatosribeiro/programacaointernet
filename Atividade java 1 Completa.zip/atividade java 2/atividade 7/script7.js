let valor1 = document.querySelector("#valor1");
let btsomar = document.querySelector("#btsomar");
let resultado = document.querySelector("#resultado");

function maiorentreeles(){

let num1 = Number(valor1.value);

if( num1% 2==0){

    resultado.textContent = "numero e par"

}

else if(num1% 2==1){

    resultado.textContent ="numero e impar"
}

else{

    resultado.textContent ="numero invalido"

}

}

btsomar.onclick = function (){
    maiorentreeles();
}

