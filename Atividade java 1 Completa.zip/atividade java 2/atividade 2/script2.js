let valorquilo = document.querySelector("#valorquilo");
let quantidade = document.querySelector("#quantidade");
let btsomar = document.querySelector("#btsomar");
let resultado = document.querySelector("#resultado");

function quiloproduto(){

let num1 = Number (valorquilo.value) 
let num2 = Number (quantidade.value)

resultado.textContent = (num1 * num2);
 
}

btsomar.onclick = function (){

    quiloproduto();
}