let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let valor3 = document.querySelector("#valor3");
let valor4 = document.querySelector("#valor4");
let btsomar = document.querySelector("#btsomar");
let resultado = document.querySelector("#resultado");

function menorentreeles(){

let num1 = Number(valor1.value);
let num2 = Number(valor2.value);
let num3 = Number(valor3.value);
let num4 = Number(valor4.value);


if(num1 < num2 && num1 < num3 && num1 < num4 ){

    resultado.textContent = "valor1 e menor que todos";
}
else if(num2 < num1 && num2 < num3 && num2 < num4)

    resultado.textContent = "valor2 e menor que todos";

else if(num3 < num1 && num3 < num2 && num3 < num4)

    resultado.textContent = "valor3 e menor que todos";

else{
    
    resultado.textContent = "valor4 e menor que todos";
}

}

btsomar.onclick = function (){
    menorentreeles();
}
