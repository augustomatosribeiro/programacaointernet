let media1 = document.querySelector("#media1");
let media2 = document.querySelector("#media2");
let media3 = document.querySelector("#media3");
let btsomar = document.querySelector("#btsomar");
let resultadoaritmetica = document.querySelector("#resultadoaritmetica");
let resultadopondereda = document.querySelector("#resultadopondereda");
let resultadodasmedias = document.querySelector("#resultadodasmedias");
let resultadomediadasmedias = document.querySelector("#resultadomediadasmedias");

function mediageral (){

let num1 = Number (media1.value)
let num2 = Number (media2.value)
let num3 = Number (media3.value)

let mediaaritimetica = (num1 + num2 + num3) /3

let mediaponderada = ( num1 + num2 + num3 * 5) / (3 + 2 + 5);

let somamedias = mediaaritimetica + mediaponderada;

let mediadasmedias = (mediaaritimetica + mediaponderada) / 2

resultadoaritmetica.textContent = mediaaritimetica
resultadopondereda.textContent =mediaponderada
resultadodasmedias.textContent =somamedias
resultadomediadasmedias.textContent =mediadasmedias

}
btsomar.onclick  = function (){
        mediageral();

}