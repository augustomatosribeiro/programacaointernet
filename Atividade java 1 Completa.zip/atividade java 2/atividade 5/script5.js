let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let btsomar = document.querySelector("#btsomar");
let resultado = document.querySelector("#resultado");

function maiorentreeles(){

let num1 = Number(valor1.value);
let num2 = Number(valor2.value);


if(num1 > num2){

    resultado.textContent = "valor1 e maior que valor2";
}
else{
    resultado.textContent = "valor2 e maior que valor1 ";
}

}

btsomar.onclick = function (){
    maiorentreeles();
}

